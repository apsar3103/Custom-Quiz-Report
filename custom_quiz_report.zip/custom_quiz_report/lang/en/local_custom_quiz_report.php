<?php
/**
 * Provides lang strings for the course modules list block.
 * @package    local_custom_quiz_report
 * @subpackage (optional)
 * @copyright  2024 LMS
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
$string['pluginname'] = 'Custom Quiz Report';
$string['selectcourse'] = 'Select a course';
$string['viewreport'] = 'View Report';
$string['studentname'] = 'Student Name';
$string['quizname'] = 'Quiz Name';
$string['quizscore'] = 'Quiz Score';
$string['nocourses'] = 'No courses available';
$string['noquizzes'] = 'No quizzes found for the selected course';
