<?php
/**
 * configuring the course modules list block capabilities
 *
 * @package    local_custom_quiz_report
 * @copyright  2024 LMS
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();

$capabilities = [
    'local/custom_quiz_report:view' => [
        'captype' => 'read',
        'contextlevel' => CONTEXT_SYSTEM, // System-level capability.
        'archetypes' => [
            'manager' => CAP_ALLOW, // Automatically allow managers to access.
        ],
    ],
];