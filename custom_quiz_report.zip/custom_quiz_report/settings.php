<?php
defined('MOODLE_INTERNAL') || die;

if ($hassiteconfig) {
    // Add the custom report page under the Reports section in the admin menu.
    $reporturl = new moodle_url('/local/custom_quiz_report/index.php'); // The URL to your report page.

    // Add the report page under the Reports menu
    $ADMIN->add('reports', new admin_externalpage(
        'custom_quiz_report', // Unique ID for this page
        get_string('pluginname', 'local_custom_quiz_report'), // The link text (name of the report)
        $reporturl->out(), // The URL of the report page
        'moodle/site:config' // Required capability (only admins can access by default)
    ));
}
