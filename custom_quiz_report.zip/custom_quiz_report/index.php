<?php
require_once('../../config.php');

require_login();
$context = context_system::instance();
require_capability('local/custom_quiz_report:view', $context);

$PAGE->set_url(new moodle_url('/local/custom_quiz_report/index.php'));
$PAGE->set_context($context);
$PAGE->set_title(get_string('pluginname', 'local_custom_quiz_report'));
$PAGE->set_heading(get_string('pluginname', 'local_custom_quiz_report'));

// Include DataTables library
$PAGE->requires->css(new moodle_url('https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css'));
$PAGE->requires->js(new moodle_url('https://code.jquery.com/jquery-3.6.4.min.js'), true);
$PAGE->requires->js(new moodle_url('https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js'), true);

echo $OUTPUT->header();

// Fetch all courses.
$courses = $DB->get_records('course', ['visible' => 1], 'fullname ASC', 'id, fullname');

// Display the course selection form with simple design.
echo '<div class="container-fluid mt-4">';
echo '<form method="post" class="form-inline">';
echo '<div class="form-group mb-2">';
echo '<label for="courseid" class="mr-2">' . get_string('selectcourse', 'local_custom_quiz_report') . '</label>&nbsp;';
echo '<select name="courseid" id="courseid" class="form-control" style="width: 300px;">';
//echo '<option value="" disabled selected>' . get_string('selectcourse', 'local_custom_quiz_report') . '</option>';

// Fetch and display the courses (assuming $courses is fetched)
foreach ($courses as $course) {
    $selected = isset($_POST['courseid']) && $_POST['courseid'] == $course->id ? 'selected' : '';
    echo '<option value="' . $course->id . '" ' . $selected . '>' . $course->fullname . '</option>';
}
echo '</select>';
echo '</div>';
echo '<button type="submit" class="btn btn-primary mb-2" style="margin-left:10px;">' . get_string('viewreport', 'local_custom_quiz_report') . '</button>';
echo '</form>';
echo '</div>'; // Close container.

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['courseid'])) {
    $courseid = (int)$_POST['courseid'];

    // Fetch quizzes in the selected course.
    $quizzes = $DB->get_records('quiz', ['course' => $courseid], 'name ASC', 'id, name');

    if ($quizzes) {
        //echo html_writer::tag('h3', get_string('pluginname', 'local_custom_quiz_report'));

        // Generate the table.
        echo '<table id="reportTable" class="display">';
        echo '<thead>';
        echo '<tr>';
        echo '<th>' . get_string('studentname', 'local_custom_quiz_report') . '</th>';
        echo '<th>' . get_string('quizname', 'local_custom_quiz_report') . '</th>';
        echo '<th>' . get_string('quizscore', 'local_custom_quiz_report') . '</th>';
        echo '</tr>';
        echo '</thead>';
        echo '<tbody>';

        foreach ($quizzes as $quiz) {
            // Fetch quiz attempts and student scores.
            $attempts = $DB->get_records_sql("
                SELECT qa.id, u.firstname, u.lastname, qa.sumgrades
                FROM {quiz_attempts} qa
                JOIN {user} u ON qa.userid = u.id
                WHERE qa.quiz = ?
                AND qa.state = 'finished'
            ", [$quiz->id]);
            //print_r($attempts);exit;
            foreach ($attempts as $attempt) {
                echo '<tr>';
                echo '<td>' . $attempt->firstname . ' ' . $attempt->lastname . '</td>';
                echo '<td>' . $quiz->name . '</td>';
                echo '<td>' . round($attempt->sumgrades, 2) . '</td>';
                echo '</tr>';
            }
        }

        echo '</tbody>';
        echo '</table>';

        // Initialize DataTables.
        echo "<script>
            $(document).ready(function() {
                $('#reportTable').DataTable({
                    'pageLength': 10,
                    'lengthChange': false,
                    'searching': true,
                    'ordering': true,
                    'info': true,
                    'autoWidth': false
                });
            });
        </script>";
    } else {
        echo html_writer::tag('p', get_string('noquizzes', 'local_custom_quiz_report'));
    }
} else {
    // In case no course is selected, show the form again.
    //echo html_writer::tag('p', get_string('selectcourse', 'local_custom_quiz_report'));
}

echo $OUTPUT->footer();
