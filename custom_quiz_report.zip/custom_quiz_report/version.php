<?php
/**
 * Listing the version details.
 * File: version.php
 * Description: explained the version details
 * @package block_quizperformancereport
 * @copyright 2024 LMS
 * @license http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_custom_quiz_report';
$plugin->version = 2024112600;
$plugin->requires = 2020110900; // Moodle 3.10 or later
$plugin->maturity = MATURITY_STABLE;
$plugin->release = '1.0';
